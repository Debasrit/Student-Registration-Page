package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRegistrionPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRegistrionPageApplication.class, args);
	}

}
