// src/app/student-update/student-update.component.ts

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student.service';
import { Student } from '../student.model';

@Component({
  selector: 'app-student-update',
  templateUrl: './student-update.component.html',
  styleUrls: ['./student-update.component.css']
})
export class StudentUpdateComponent implements OnInit {

  studentId: number = -1;
  student!: Student;

  constructor(private route: ActivatedRoute, private router: Router, private studentService: StudentService) { }

  ngOnInit(): void {
    this.studentId = this.route.snapshot.params['id'];
    this.studentService.getStudentById(this.studentId)
      .subscribe(student => this.student = student);
  }

  updateStudent(): void {
    this.studentService.updateStudent(this.studentId, this.student)
      .subscribe(() => this.router.navigate(['/students']));
  }
}

